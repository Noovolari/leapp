export interface AuthorDto {
    id: string;
    name: string;
    surname: string;
    email: string;
}
