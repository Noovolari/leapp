export interface AuthorModel {
    id: string;
    name: string;
    surname: string;
    email: string;
}
