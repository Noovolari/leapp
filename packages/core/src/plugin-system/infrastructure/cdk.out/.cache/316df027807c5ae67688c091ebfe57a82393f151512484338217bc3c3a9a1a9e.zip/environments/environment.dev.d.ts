export declare const environment: {
    TZ?: string;
    production: boolean;
    name: string;
};
