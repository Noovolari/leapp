declare let environment: {
    [key: string]: string;
};
export { environment };
