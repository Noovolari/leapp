export interface StatusRdsModel {
    id: string;
    name: string;
}
