export interface PluginExtendedModel {
    id: string;
    title: string;
    author: string;
    pubdate: string;
    updatedate: string;
    email: string;
    icon: string;
    url: string;
    description: string;
    image: string;
}
