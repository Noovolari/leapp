import * as express from 'express';
export declare function RegisterRoutes(app: express.Router): void;
