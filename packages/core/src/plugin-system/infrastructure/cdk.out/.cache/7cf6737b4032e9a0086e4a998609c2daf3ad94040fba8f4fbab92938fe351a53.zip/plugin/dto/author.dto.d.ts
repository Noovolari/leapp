export interface AuthorDto {
    id: string;
    name: string;
    email: string;
}
