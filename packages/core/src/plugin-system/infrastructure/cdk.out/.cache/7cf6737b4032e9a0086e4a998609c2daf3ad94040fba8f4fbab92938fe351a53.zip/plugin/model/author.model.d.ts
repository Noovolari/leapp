export interface AuthorModel {
    id: string;
    name: string;
    email: string;
}
