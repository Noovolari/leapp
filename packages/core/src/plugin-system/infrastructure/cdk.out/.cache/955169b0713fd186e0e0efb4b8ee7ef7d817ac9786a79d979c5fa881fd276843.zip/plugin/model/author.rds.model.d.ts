export interface AuthorRdsModel {
    id: string;
    name: string;
    surname: string;
    email: string;
}
