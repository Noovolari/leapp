export interface StatusModel {
    id: string;
    name: string;
}
