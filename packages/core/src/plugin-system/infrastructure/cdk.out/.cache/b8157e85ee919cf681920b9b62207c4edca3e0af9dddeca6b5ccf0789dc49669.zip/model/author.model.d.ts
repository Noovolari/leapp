export interface AuthorModel {
    name: string;
    email: string;
}
