"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.environment = void 0;
exports.environment = {
    production: false,
    name: "local",
    ...process.env,
};
//# sourceMappingURL=environment.local.js.map