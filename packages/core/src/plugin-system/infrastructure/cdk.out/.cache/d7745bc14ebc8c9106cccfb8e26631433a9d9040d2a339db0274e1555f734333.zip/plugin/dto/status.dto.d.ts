export interface StatusDto {
    id: string;
    name: string;
}
