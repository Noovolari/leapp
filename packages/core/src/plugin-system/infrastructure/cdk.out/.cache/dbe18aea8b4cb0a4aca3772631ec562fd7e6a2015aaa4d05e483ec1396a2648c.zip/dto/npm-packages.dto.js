"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NpmPackagesDto = void 0;
class NpmPackagesDto {
}
exports.NpmPackagesDto = NpmPackagesDto;
//# sourceMappingURL=npm-packages.dto.js.map